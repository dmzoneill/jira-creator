from jira.client import JiraClient
from unittest.mock import MagicMock


def test_change_issue_type():
    client = JiraClient()

    # Mock the request method
    mock_request = MagicMock()
    # First call: GET request to fetch issue details
    mock_request.side_effect = lambda method, path, **kwargs: {"fields": {"issuetype": {"subtask": True}}} if method == "GET" else {}

    # Assign the mocked _request method to the client
    client._request = mock_request

    # Call the method
    client.change_issue_type("AAP-1", "story")

    # Assert that the GET request was called to retrieve the issue
    mock_request.assert_any_call("GET", "/rest/api/2/issue/AAP-1")

    # Assert that the PUT request was called to change the issue type
    mock_request.assert_any_call(
        "PUT",
        "/rest/api/2/issue/AAP-1",
        json={
            'fields': {'issuetype': {'name': 'Story'}},
            'update': {'parent': [{'remove': {}}]}
        },
        allow_204=True
    )
